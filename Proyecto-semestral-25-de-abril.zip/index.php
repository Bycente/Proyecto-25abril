<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" >
    <title> Logo kit Invermadero </title> 
    <link rel="stylesheet" href="estilos.css" /> 
    
  </head>
  
  <body>
    
    <h1>Logo Kit Invernadero</h1>
    
    <nav>
      
    <button class= "button1"onclick="verHumedad()">Ver mediciones de humedad</button>
    
    <button class= "button2" onclick="verLuminosidad()">Ver mediciones de luminosidad</button>

    <button class= "button3" onclick="verEventos()">Ver eventos detectados</button>
      
  </nav>                                                       
    
    <p id="humedad"  class="info-container"></p> 
  
    <p id="luminosidad"  class="info-container"></p>   
    
    <p id="eventos"  class="info-container"></p>
    
    
    <script>
      function verHumedad() {
        ocultarInfo();
        var tabdeHumedad1 = "<table><tr><th>Fecha</th><th>Hora</th><th>Humedad de suelo</th></tr><tr><td>xxxxx</td><td>yy:yy:yy</td><td>zz</td></table>" 
        var tabdeHumedad2 = "<table><tr><th>Fecha</th><th>Hora</th><th>Humedad de suelo</th></tr><tr><td>xxxxx</td><td>yy:yy:yy</td><td>zz</td></table>"
        var tabdeHumedad3 = "<table><tr><th>Fecha</th><th>Hora</th><th>Humedad de suelo</th></tr><tr><td>xxxxx</td><td>yy:yy:yy</td><td>zz</td></table>" 
        var tabdeHumedad4 = "<table><tr><th>Fecha</th><th>Hora</th><th>Humedad de suelo</th></tr><tr><td>xxxxx</td><td>yy:yy:yy</td><td>zz</td></table>" 
        var tabdeHumedad5 = "<table><tr><th>Fecha</th><th>Hora</th><th>Humedad de suelo</th></tr><tr><td>xxxxx</td><td>yy:yy:yy</td><td>zz</td></table>" 
        
        document.getElementById("humedad").innerHTML = tabdeHumedad1 + tabdeHumedad2 + tabdeHumedad3
        + tabdeHumedad4 + tabdeHumedad5; 
          
        document.getElementById("humedad").style.display = "block";
      }
      
      function verLuminosidad() {
        ocultarInfo();
        var tabdeLuminosidad1 = "<table><tr><th>Fecha</th><th>Hora de apertura</th><th>Toldo hora cierre toldo</th></tr><tr><td>xxxxx</td><td>yy:yy:yy</td><td>zz:zz:zz</td></table>"
        var tabdeLuminosidad2 = "<table><tr><th>Fecha</th><th>Hora de apertura</th><th>Toldo hora cierre toldo</th></tr><tr><td>xxxxx</td><td>yy:yy:yy</td><td>zz:zz:zz</td></table>" 
        var tabdeLuminosidad3 = "<table><tr><th>Fecha</th><th>Hora de apertura</th><th>Toldo hora cierre toldo</th></tr><tr><td>xxxxx</td><td>yy:yy:yy</td><td>zz:zz:zz</td></table>" 
        var tabdeLuminosidad4 = "<table><tr><th>Fecha</th><th>Hora de apertura</th><th>Toldo hora cierre toldo</th></tr><tr><td>xxxxx</td><td>yy:yy:yy</td><td>zz:zz:zz</td></table>" 
        var tabdeLuminosidad5 = "<table><tr><th>Fecha</th><th>Hora de apertura</th><th>Toldo hora cierre toldo</th></tr><tr><td>xxxxx</td><td>yy:yy:yy</td><td>zz:zz:zz</td></table>" 
        
        document.getElementById("luminosidad").innerHTML = tabdeLuminosidad1 + tabdeLuminosidad2 + tabdeLuminosidad3 + tabdeLuminosidad4 + tabdeLuminosidad5 ;
        document.getElementById("luminosidad").style.display = "block";
      }
      
      function verEventos() {
        ocultarInfo();
        var tabdeEventos1 = "<table><tr><th>Fecha</th><th>Hora</th><th>Distancia</th></tr><tr><td>xxxxx</td><td>yy:yy:yy</td><td>1.6 Mts</td></table>"
        var tabdeEventos2 = "<table><tr><th>Fecha</th><th>Hora</th><th>Distancia</th></tr><tr><td>xxxxx</td><td>yy:yy:yy</td><td>3.7 Mts</td></table>"
        var tabdeEventos3 = "<table><tr><th>Fecha</th><th>Hora</th><th>Distancia</th></tr><tr><td>xxxxx</td><td>yy:yy:yy</td><td>0.2 Mts</td></table>"
        var tabdeEventos4 = "<table><tr><th>Fecha</th><th>Hora</th><th>Distancia</th></tr><tr><td>xxxxx</td><td>yy:yy:yy</td><td>6.1 Mts</td></table>"
        var tabdeEventos5 = "<table><tr><th>Fecha</th><th>Hora</th><th>Distancia</th></tr><tr><td>xxxxx</td><td>yy:yy:yy</td><td>5.9 Mts</td></table>"
        
        document.getElementById("eventos").innerHTML = tabdeEventos1 + tabdeEventos2 + tabdeEventos3 + tabdeEventos4 + tabdeEventos5 ;
        document.getElementById("eventos").style.display = "block";
      }
      
      function ocultarInfo() {
        var elementosInfo = document.getElementsByClassName("info-container");
        for (var i = 0; i < elementosInfo.length; i++) {
          elementosInfo[i].style.display = "none";
        }
      }
    
    </script>
    
    <article class="article">
      <h2>
      <i>Descripcion del proyecto</i>
      </h2>
      <p> 
      En este proyecto veremos un prototipo IOT que sirve para 
      ayudar a los invernaderos locales a reducir las pérdidas 
      causadas por los cambios de temperatura, sequía del suelo y 
      la presencia de aves. Para que funcione, se debe incluir la 
      detección de niveles de humedad para activar un grifo que 
      libere agua para hidratar el suelo.
      </p>
      </article>
      
    <article class="article">
      <h2>
      <i>Nieveles de humedad</i>
      </h2>
      <p> 
      A la fecha se han realizado XYZ mediciones. <br>
      La medicion de humedad mas alta realizada es X <br>
      La medicion de humedad mas baja realizada es Y <br>
      La medicion de humedad promedio es Z <br>  
      </p>
      </article>

     <article class="article">
      <h2>
      <i>Eventos</i>
      </h2>
      <p> 
       A la fecha se han detectado XYZ eventos. <br>
       Se han detectado X eventos de activacion de riesgo de 
       sequedad del suelo. <br>
       Se han detectado Y eventos de activacion de toldo protector 
       por proximidad por aves. <br>
       Se han detectado z eventos de activacion de toldo protector 
       por bajos niveles de luz. <br>  
      </p>
      </article>
  </body>
</html>
